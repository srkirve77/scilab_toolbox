Hi Davis,
thanks for your work on dlib!
 
I have created a natvis file to have nicer debugger visualization of dlib matrices in Visual Studio (2012 - …) and I just wanted to share it with you.
 
To test it, copy the file into you folder  %USERPROFILE%\My Documents\Visual Studio 2015\Visualizers or %VSINSTALLDIR%\Common7\Packages\Debugger\Visualizers as described here https://msdn.microsoft.com/en-us/library/jj620914.aspx
 
It’s certainly extendable, especially to include it into image watch, but currently it may help users to debug much faster.
 
Feel free to share it.
Best,
    Johannes Huber
