int mul(double* answ, double num1, double num2);
