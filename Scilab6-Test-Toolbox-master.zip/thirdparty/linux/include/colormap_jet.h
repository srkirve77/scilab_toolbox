#include "dlib/image_transforms/colormaps.h"
dlib::rgb_pixel colormap_jet_call( double val, double min_val,double max_val);