#include<bits/stdc++.h>
using namespace std;
int add(double *ans , vector<int> a);
