#include "dlib/optimization/max_cost_assignment.h"
#include <iostream>
using namespace std;
using namespace dlib;
long assignment_cost_call(dlib::matrix<int>cost ,std::vector<long>  assignment);