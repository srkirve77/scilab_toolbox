#include "dlib/rand/rand_kernel_1.h"
double get_random_call(dlib::rand *random);