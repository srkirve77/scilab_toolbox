#include<bits/stdc++.h>
#include "dlib/gui_widgets.h"
#include "dlib/image_transforms.h"
using namespace std;

int perspective_window_call(std::vector<dlib::perspective_window::overlay_dot> points);
