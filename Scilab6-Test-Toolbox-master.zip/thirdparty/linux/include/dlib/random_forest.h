// Copyright (C) 2018  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_RANDOM_FOReST_H_
#define DLIB_RANDOM_FOReST_H_

#include "random_forest/random_forest_regression.h"

#endif // DLIB_RANDOM_FOReST_H_


