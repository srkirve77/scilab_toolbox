#include <iostream>
#include <vector>
#include "dlib/statistics.h"
using namespace std;
using namespace dlib;
void statistics_info(std::vector<double>&answer,std::vector<double> data , dlib::running_stats<double>*rs);
