#ifndef __TEST_TOOLBOX_GW_H__
#define __TEST_TOOLBOX_GW_H__

#include "c_gateway_prototype.h"

C_GATEWAY_PROTOTYPE(sci_multiply);

#endif /* __TEST_TOOLBOX_GW_H__ */
