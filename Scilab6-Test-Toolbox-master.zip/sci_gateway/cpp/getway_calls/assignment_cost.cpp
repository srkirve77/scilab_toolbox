#include "assignment_cost.h"
long assignment_cost_call( matrix<int> cost ,std::vector<long>  assignment)
{
	return assignment_cost(cost,assignment);
}