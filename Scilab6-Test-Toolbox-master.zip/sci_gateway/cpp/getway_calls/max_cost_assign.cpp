#include "max_cost_assign.h"
std::vector<long> max_cost_assignment_call (matrix<int> cost)
{
	return max_cost_assignment(cost);
}
